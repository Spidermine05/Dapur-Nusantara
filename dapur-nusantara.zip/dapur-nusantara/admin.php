<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/render.php';
require_admin();

$pdo   = db();
$flash = ['ok' => '', 'err' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid($_POST['csrf'] ?? null)) {
        $flash['err'] = 'Sesi kedaluwarsa. Silakan coba lagi.';
    } else {
        $action = (string)($_POST['action'] ?? '');
        $id     = (int)($_POST['id'] ?? 0);

        if ($action === 'read') {
            $pdo->prepare('UPDATE messages SET is_read = 1 WHERE id = ?')->execute([$id]);
        } elseif ($action === 'unread') {
            $pdo->prepare('UPDATE messages SET is_read = 0 WHERE id = ?')->execute([$id]);
        } elseif ($action === 'delete') {
            $pdo->prepare('DELETE FROM messages WHERE id = ?')->execute([$id]);
            $flash['ok'] = 'Pesan dihapus.';
        } elseif ($action === 'readall') {
            $pdo->exec('UPDATE messages SET is_read = 1');
            $flash['ok'] = 'Semua pesan ditandai sudah dibaca.';
        } elseif ($action === 'password') {
            $st = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
            $st->execute([$_SESSION['uid']]);
            $hash = (string)$st->fetchColumn();
            $new  = (string)($_POST['new'] ?? '');
            if (!password_verify((string)($_POST['current'] ?? ''), $hash)) {
                $flash['err'] = 'Kata sandi saat ini salah.';
            } elseif (strlen($new) < 8) {
                $flash['err'] = 'Kata sandi baru minimal 8 karakter.';
            } elseif ($new !== (string)($_POST['confirm'] ?? '')) {
                $flash['err'] = 'Konfirmasi kata sandi baru tidak sama.';
            } else {
                $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
                    ->execute([password_hash($new, PASSWORD_DEFAULT), $_SESSION['uid']]);
                $flash['ok'] = 'Kata sandi berhasil diganti.';
            }
        }
    }
}

$messages = $pdo->query('SELECT * FROM messages ORDER BY id DESC')->fetchAll();
$unread   = count(array_filter($messages, fn($m) => !(int)$m['is_read']));
$csrf     = csrf_token();
?><!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title>Pesan Masuk · <?= et('brand.name') ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="page-admin">
    <header class="admin-top">
        <div class="container admin-top-in">
            <a href="index.php" class="auth-brand"><?= icon('flame', 22) ?> <span><?= et('brand.name') ?></span></a>
            <a href="index.php" class="btn btn-gold btn-sm"><?= icon('pencil', 16) ?> Kembali ke Website</a>
        </div>
    </header>

    <main class="container admin-main">
        <h1>Pesan Masuk <?php if ($unread): ?><span class="badge"><?= $unread ?> baru</span><?php endif; ?></h1>

        <?php if ($flash['ok']): ?><div class="alert alert-ok" role="status"><?= e($flash['ok']) ?></div><?php endif; ?>
        <?php if ($flash['err']): ?><div class="alert alert-err" role="alert"><?= e($flash['err']) ?></div><?php endif; ?>

        <?php if ($messages): ?>
            <form method="post" class="admin-actions">
                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                <input type="hidden" name="action" value="readall">
                <button class="btn btn-ghost btn-sm" type="submit">Tandai semua sudah dibaca</button>
            </form>
            <div class="msg-list">
                <?php foreach ($messages as $m):
                    $contact = (string)$m['contact'];
                    $wa = preg_match('/^[+()\d\s-]{8,}$/', $contact) ? wa_number($contact) : '';
                    $mail = filter_var($contact, FILTER_VALIDATE_EMAIL) ? $contact : '';
                ?>
                    <article class="msg <?= (int)$m['is_read'] ? '' : 'msg-new' ?>">
                        <div class="msg-head">
                            <strong><?= e($m['name']) ?></strong>
                            <time><?= e(date('d M Y, H:i', strtotime((string)$m['created_at']))) ?></time>
                        </div>
                        <div class="msg-contact">
                            <?= e($contact) ?>
                            <?php if ($wa): ?> · <a href="https://wa.me/<?= e($wa) ?>" target="_blank" rel="noopener">Balas via WhatsApp</a><?php endif; ?>
                            <?php if ($mail): ?> · <a href="mailto:<?= e($mail) ?>">Balas via email</a><?php endif; ?>
                        </div>
                        <p class="pl"><?= e($m['message']) ?></p>
                        <form method="post" class="msg-actions">
                            <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                            <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
                            <?php if ((int)$m['is_read']): ?>
                                <button class="link-btn" name="action" value="unread">Tandai belum dibaca</button>
                            <?php else: ?>
                                <button class="link-btn" name="action" value="read">Tandai sudah dibaca</button>
                            <?php endif; ?>
                            <button class="link-btn danger" name="action" value="delete"
                                    onclick="return confirm('Hapus pesan ini?')">Hapus</button>
                        </form>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-box"><?= icon('inbox', 36) ?><p>Belum ada pesan masuk.</p></div>
        <?php endif; ?>

        <section class="card-box">
            <h2>Ganti Kata Sandi</h2>
            <form method="post" class="form form-inline">
                <input type="hidden" name="csrf" value="<?= e($csrf) ?>">
                <input type="hidden" name="action" value="password">
                <label>Kata sandi saat ini <input type="password" name="current" required autocomplete="current-password"></label>
                <label>Kata sandi baru <input type="password" name="new" required minlength="8" autocomplete="new-password"></label>
                <label>Ulangi kata sandi baru <input type="password" name="confirm" required minlength="8" autocomplete="new-password"></label>
                <button class="btn btn-gold" type="submit">Simpan Kata Sandi</button>
            </form>
        </section>
    </main>
</body>
</html>
