<?php
declare(strict_types=1);

/**
 * Semua teks bawaan website.
 * Kunci (mis. 'hero.title') sama dengan atribut data-edit di index.php.
 * Teks yang diubah lewat mode edit disimpan di database dan menggantikan nilai ini.
 */
function defaults(): array
{
    return [
        // Identitas
        'brand.name'    => 'Dapur Nusantara',
        'brand.tagline' => 'Restoran & Katering Nusantara',

        // Hero
        'hero.eyebrow'  => 'Restoran & Katering · Sejak 2012',
        'hero.title'    => 'Cita Rasa Warisan, Disajikan dengan Hati',
        'hero.subtitle' => 'Hidangan Nusantara autentik dari bahan segar pilihan dan rempah yang diracik setiap hari di dapur kami.',
        'hero.btn1'     => 'Lihat Menu',
        'hero.btn2'     => 'Reservasi Meja',

        // Statistik
        'stat1.num' => '12+',   'stat1.label' => 'Tahun Berpengalaman',
        'stat2.num' => '50+',   'stat2.label' => 'Pilihan Menu',
        'stat3.num' => '10rb+', 'stat3.label' => 'Pelanggan Puas',
        'stat4.num' => '4,8',   'stat4.label' => 'Rating Rata-rata',

        // Tentang
        'about.eyebrow' => 'Tentang Kami',
        'about.title'   => 'Dari Dapur Keluarga, untuk Meja Anda',
        'about.p1'      => 'Dapur Nusantara bermula dari sebuah dapur kecil keluarga yang percaya bahwa makanan enak lahir dari bahan terbaik dan resep yang dijaga turun-temurun.',
        'about.p2'      => 'Hari ini kami melayani makan di tempat, pesan antar, hingga katering acara. Setiap hidangan tetap dimasak dengan perhatian yang sama seperti hari pertama.',
        'about.point1'  => 'Bahan segar dari petani dan nelayan lokal',
        'about.point2'  => 'Bumbu diracik sendiri tanpa pengawet',
        'about.point3'  => 'Melayani acara dari 10 hingga 1.000 tamu',

        // Keunggulan
        'why.eyebrow'  => 'Keunggulan',
        'why.title'    => 'Mengapa Memilih Kami',
        'why1.title'   => 'Bahan Segar Pilihan',
        'why1.text'    => 'Kami memilih sendiri bahan setiap pagi agar rasa dan kualitasnya selalu terjaga.',
        'why2.title'   => 'Resep Warisan',
        'why2.text'    => 'Racikan bumbu tradisional yang dijaga keasliannya dan disempurnakan oleh koki kami.',
        'why3.title'   => 'Layanan Sepenuh Hati',
        'why3.text'    => 'Tim yang ramah dan sigap, baik untuk makan santai maupun acara spesial Anda.',

        // Menu
        'menu.eyebrow'  => 'Menu Kami',
        'menu.title'    => 'Sajian Favorit Pelanggan',
        'menu.subtitle' => 'Dari hidangan utama yang mengenyangkan hingga penutup manis yang menenangkan.',

        // Galeri
        'gallery.eyebrow' => 'Suasana',
        'gallery.title'   => 'Ruang Hangat untuk Berbagi Cerita',

        // Testimoni
        'testi.eyebrow' => 'Testimoni',
        'testi.title'   => 'Kata Mereka tentang Kami',
        't1.text' => 'Rendangnya empuk dan bumbunya meresap sempurna. Rasanya persis masakan rumah nenek. Kami pasti kembali.',
        't1.name' => 'Rina Wulandari',
        't1.role' => 'Pelanggan setia',
        't2.text' => 'Pesan katering untuk acara 200 tamu, semuanya tepat waktu dan rapi. Tamu-tamu kami sangat puas.',
        't2.name' => 'Budi Santoso',
        't2.role' => 'Penyelenggara acara',
        't3.text' => 'Tempatnya nyaman, pelayanannya ramah, dan harganya masuk akal. Cocok untuk makan bersama keluarga.',
        't3.name' => 'Maya Anggraini',
        't3.role' => 'Food blogger',

        // Ajakan (CTA)
        'cta.title' => 'Rayakan Momen Spesialmu Bersama Kami',
        'cta.text'  => 'Ulang tahun, arisan, pernikahan, hingga acara kantor. Biarkan kami yang menyiapkan hidangannya.',
        'cta.btn'   => 'Pesan Katering',

        // Kontak
        'contact.eyebrow'   => 'Hubungi Kami',
        'contact.title'     => 'Reservasi & Pemesanan',
        'contact.text'      => 'Tinggalkan pesan dan tim kami akan menghubungi Anda secepatnya.',
        'contact.address'   => 'Jl. Rasa Utama No. 12, Kota Anda',
        'contact.phone'     => '0812-3456-7890',
        'contact.email'     => 'halo@dapurnusantara.id',
        'contact.whatsapp'  => '081234567890',
        'contact.hours1'    => 'Senin – Jumat: 10.00 – 22.00',
        'contact.hours2'    => 'Sabtu – Minggu: 09.00 – 23.00',
        'contact.instagram' => 'dapurnusantara',

        // Footer
        'footer.text' => 'Menyajikan cita rasa Nusantara dengan sepenuh hati sejak 2012.',
    ];
}

/** Kunci gambar yang boleh diganti lewat mode edit. */
function image_keys(): array
{
    return ['img.hero', 'img.about', 'img.gal1', 'img.gal2', 'img.gal3'];
}

/** Menu contoh yang dimasukkan sekali saat pertama dijalankan. [kategori, nama, deskripsi, harga] */
function seed_menu(): array
{
    return [
        ['Hidangan Utama', 'Nasi Liwet Komplit', 'Nasi gurih berbumbu daun salam dan serai, disajikan dengan ayam goreng, tahu, tempe, lalapan, dan sambal.', 48000],
        ['Hidangan Utama', 'Rendang Daging Sapi', 'Daging sapi empuk dimasak perlahan dalam santan dan rempah pilihan hingga bumbunya meresap.', 65000],
        ['Hidangan Utama', 'Ayam Bakar Bumbu Rujak', 'Ayam kampung dibakar dengan bumbu rujak manis pedas, ditemani nasi hangat dan sambal terasi.', 52000],
        ['Makanan Ringan', 'Pisang Goreng Madu', 'Pisang kepok goreng renyah di luar, lembut di dalam, dengan siraman madu dan taburan wijen.', 22000],
        ['Makanan Ringan', 'Tahu Crispy Sambal Matah', 'Tahu goreng tepung renyah dengan sambal matah segar khas Bali.', 25000],
        ['Minuman', 'Es Teh Tarik Rempah', 'Teh hitam pekat dengan susu dan sentuhan kayu manis, disajikan dingin.', 18000],
        ['Minuman', 'Wedang Jahe Serai', 'Minuman hangat dari jahe, serai, dan gula aren yang menenangkan.', 16000],
        ['Penutup', 'Klepon Gula Aren', 'Bola ketan hijau berisi gula aren cair, digulung kelapa parut segar.', 24000],
    ];
}
