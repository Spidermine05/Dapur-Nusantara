<?php
declare(strict_types=1);

/**
 * Inti aplikasi: konfigurasi, database (SQLite), sesi, dan fungsi bantu.
 * Dimuat oleh semua halaman dan API.
 */

define('ROOT', dirname(__DIR__));
define('DATA_DIR', ROOT . '/data');
define('UPLOAD_DIR', ROOT . '/uploads');
define('DB_FILE', DATA_DIR . '/site.sqlite');
define('MAX_UPLOAD', 5 * 1024 * 1024); // 5 MB

date_default_timezone_set('Asia/Jakarta');

require_once __DIR__ . '/defaults.php';

if (PHP_SAPI !== 'cli') {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
}

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure'   => !empty($_SERVER['HTTPS']),
    ]);
    session_name('dapur_sid');
    session_start();
}

/* ---------- Umum ---------- */

function e(?string $s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function json_out(array $data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function redirect(string $to): void
{
    header('Location: ' . $to);
    exit;
}

function clean_text(string $s, int $max = 2000): string
{
    $s = str_replace(["\r\n", "\r"], "\n", $s);
    $s = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $s) ?? '';
    $s = trim(preg_replace("/\n{3,}/", "\n\n", $s) ?? '');
    return function_exists('mb_substr') ? mb_substr($s, 0, $max) : substr($s, 0, $max);
}

function rupiah(int $n): string
{
    return $n > 0 ? 'Rp ' . number_format($n, 0, ',', '.') : 'Tanya harga';
}

function wa_number(string $raw): string
{
    $d = preg_replace('/\D+/', '', $raw) ?? '';
    if ($d !== '' && $d[0] === '0') {
        $d = '62' . substr($d, 1);
    }
    return $d;
}

/* ---------- Database ---------- */

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    try {
        if (!is_dir(DATA_DIR)) {
            mkdir(DATA_DIR, 0755, true);
        }
        $pdo = new PDO('sqlite:' . DB_FILE, null, null, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS menu (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                name TEXT NOT NULL,
                description TEXT NOT NULL DEFAULT '',
                price INTEGER NOT NULL DEFAULT 0,
                image TEXT
            );
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                contact TEXT NOT NULL,
                message TEXT NOT NULL,
                is_read INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            );
        ");

        // Isi menu contoh satu kali saja
        $seeded = $pdo->query("SELECT v FROM settings WHERE k = 'menu_seeded'")->fetchColumn();
        if (!$seeded) {
            $pdo->beginTransaction();
            $st = $pdo->prepare('INSERT INTO menu (category, name, description, price) VALUES (?, ?, ?, ?)');
            foreach (seed_menu() as $row) {
                $st->execute($row);
            }
            $pdo->exec("INSERT INTO settings (k, v) VALUES ('menu_seeded', '1')");
            $pdo->commit();
        }
    } catch (Throwable $ex) {
        http_response_code(500);
        exit('Database tidak dapat dibuka. Pastikan folder "data" ada dan dapat ditulis (writable), '
           . 'dan ekstensi PHP pdo_sqlite aktif. Detail: ' . e($ex->getMessage()));
    }
    return $pdo;
}

function settings_all(): array
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (db()->query('SELECT k, v FROM settings') as $r) {
            $cache[$r['k']] = $r['v'];
        }
    }
    return $cache;
}

function t(string $key): string
{
    $s = settings_all();
    return $s[$key] ?? (defaults()[$key] ?? '');
}

function img(string $key): ?string
{
    $v = settings_all()[$key] ?? '';
    return $v !== '' ? $v : null;
}

function set_setting(string $key, string $value): void
{
    $st = db()->prepare('INSERT INTO settings (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v');
    $st->execute([$key, $value]);
}

function has_users(): bool
{
    return (int)db()->query('SELECT COUNT(*) FROM users')->fetchColumn() > 0;
}

/* ---------- Autentikasi & CSRF ---------- */

function is_admin(): bool
{
    return !empty($_SESSION['uid']);
}

function require_admin(): void
{
    if (!is_admin()) {
        redirect('login.php');
    }
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_valid(?string $token): bool
{
    return is_string($token) && $token !== '' && hash_equals($_SESSION['csrf'] ?? '', $token);
}

/** Penjaga untuk semua endpoint API (POST + token CSRF + login admin bila perlu). */
function api_guard(bool $admin = true): void
{
    header('Cache-Control: no-store');
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        json_out(['ok' => false, 'error' => 'Metode tidak diizinkan.'], 405);
    }
    if (!csrf_valid($_SERVER['HTTP_X_CSRF_TOKEN'] ?? null)) {
        json_out(['ok' => false, 'error' => 'Sesi kedaluwarsa. Silakan muat ulang halaman.'], 419);
    }
    if ($admin && !is_admin()) {
        json_out(['ok' => false, 'error' => 'Silakan login terlebih dahulu.'], 401);
    }
}

/* ---------- Upload gambar ---------- */

/** Validasi dan simpan foto. Mengembalikan path relatif, mis. "uploads/ab12....jpg". */
function save_upload(array $f): string
{
    if (!isset($f['error']) || is_array($f['error'])) {
        throw new RuntimeException('Berkas tidak valid.');
    }
    if ($f['error'] === UPLOAD_ERR_NO_FILE) {
        throw new RuntimeException('Belum ada foto yang dipilih.');
    }
    if ($f['error'] === UPLOAD_ERR_INI_SIZE || $f['error'] === UPLOAD_ERR_FORM_SIZE || $f['size'] > MAX_UPLOAD) {
        throw new RuntimeException('Ukuran foto terlalu besar (maksimal 5 MB).');
    }
    if ($f['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Upload gagal. Silakan coba lagi.');
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $ext  = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
    if ($ext === null || @getimagesize($f['tmp_name']) === false) {
        throw new RuntimeException('Format foto harus JPG, PNG, atau WebP.');
    }
    if (!is_dir(UPLOAD_DIR) && !mkdir(UPLOAD_DIR, 0755, true)) {
        throw new RuntimeException('Folder uploads tidak dapat dibuat.');
    }
    $name = bin2hex(random_bytes(8)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], UPLOAD_DIR . '/' . $name)) {
        throw new RuntimeException('Foto gagal disimpan. Periksa izin folder uploads.');
    }
    return 'uploads/' . $name;
}

/** Hapus berkas upload lama (hanya yang dibuat oleh sistem ini). */
function delete_upload(?string $path): void
{
    if ($path && preg_match('#^uploads/[a-f0-9]{16}\.(jpg|png|webp)$#', $path)) {
        $full = ROOT . '/' . $path;
        if (is_file($full)) {
            @unlink($full);
        }
    }
}
