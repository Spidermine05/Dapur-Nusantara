<?php
declare(strict_types=1);

/** Pembangun HTML yang dipakai bersama oleh index.php dan api/menu.php. */

/** Atribut untuk teks yang bisa diedit (hanya muncul bila login sebagai admin). */
function ed(string $key, bool $multiline = false): string
{
    if (!is_admin()) {
        return '';
    }
    return 'data-edit="' . e($key) . '"' . ($multiline ? ' data-multiline' : '');
}

/** Teks (sudah di-escape) dari database atau bawaan. */
function et(string $key): string
{
    return e(t($key));
}

/** Tombol "Ganti foto" (hanya terlihat saat mode edit aktif). */
function media_btn(string $key, string $label = 'Ganti foto'): string
{
    if (!is_admin()) {
        return '';
    }
    return '<button type="button" class="ed-img-btn" data-upload="' . e($key) . '">'
         . icon('camera', 16) . ' ' . e($label) . '</button>';
}

function icon(string $name, int $size = 20): string
{
    $paths = [
        'pin'       => '<path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
        'phone'     => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
        'mail'      => '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
        'clock'     => '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
        'leaf'      => '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.5 19 2c1 2 2 4.2 2 8 0 5.5-4.8 10-10 10z"/><path d="M2 21c0-3 1.9-5.4 5.5-6.5 2.5-.8 4.5-2 6.5-4"/>',
        'flame'     => '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.4-.5-2-1-3-1.1-2.1-.2-4 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.2.4-2.4 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>',
        'heart'     => '<path d="M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7z"/>',
        'check'     => '<path d="M20 6 9 17l-5-5"/>',
        'chat'      => '<path d="M21 11.5a8.5 8.5 0 0 1-12.6 7.4L3 20.5l1.7-5.2A8.5 8.5 0 1 1 21 11.5z"/>',
        'instagram' => '<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r=".6"/>',
        'camera'    => '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
        'pencil'    => '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
        'inbox'     => '<path d="M22 12h-6l-2 3h-4l-2-3H2"/><path d="M5.5 5.1 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.5-6.9A2 2 0 0 0 16.7 4H7.3a2 2 0 0 0-1.8 1.1z"/>',
        'logout'    => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
        'plus'      => '<path d="M12 5v14M5 12h14"/>',
    ];
    return '<svg class="ic" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" '
         . 'stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
         . ($paths[$name] ?? '') . '</svg>';
}

/** Gambar bawaan (ilustrasi) bila belum ada foto, disesuaikan kategori. */
function placeholder_for(string $category): string
{
    $c = strtolower($category);
    if (str_contains($c, 'minum') || str_contains($c, 'drink')) {
        return 'assets/img/ph-drink.svg';
    }
    if (str_contains($c, 'penutup') || str_contains($c, 'dessert') || str_contains($c, 'manis')) {
        return 'assets/img/ph-dessert.svg';
    }
    if (str_contains($c, 'ringan') || str_contains($c, 'snack')) {
        return 'assets/img/ph-snack.svg';
    }
    return 'assets/img/ph-main.svg';
}

/** Tab kategori + kartu menu. Dipakai di halaman dan dikirim ulang oleh api/menu.php. */
function render_menu(bool $admin): string
{
    $items = db()->query('SELECT * FROM menu ORDER BY id')->fetchAll();
    $cats = [];
    foreach ($items as $it) {
        $cats[(string)$it['category']] = true;
    }

    ob_start();
    if ($items): ?>
        <div class="menu-tabs" role="tablist" aria-label="Kategori menu">
            <button type="button" class="tab is-active" data-cat="*">Semua</button>
            <?php foreach (array_keys($cats) as $c): ?>
                <button type="button" class="tab" data-cat="<?= e((string)$c) ?>"><?= e((string)$c) ?></button>
            <?php endforeach; ?>
        </div>
        <div class="menu-grid">
            <?php foreach ($items as $it):
                $src = $it['image'] ?: placeholder_for((string)$it['category']); ?>
                <article class="dish" data-cat="<?= e($it['category']) ?>"
                         data-id="<?= (int)$it['id'] ?>" data-name="<?= e($it['name']) ?>"
                         data-category="<?= e($it['category']) ?>" data-price="<?= (int)$it['price'] ?>"
                         data-desc="<?= e($it['description']) ?>" data-image="<?= e((string)$it['image']) ?>">
                    <div class="dish-img">
                        <img src="<?= e($src) ?>" alt="<?= e($it['name']) ?>" loading="lazy">
                        <?php if ($admin): ?>
                            <div class="dish-admin">
                                <button type="button" class="chip" data-menu-edit>Ubah</button>
                                <button type="button" class="chip chip-danger" data-menu-del>Hapus</button>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="dish-body">
                        <div class="dish-top">
                            <h3><?= e($it['name']) ?></h3>
                            <span class="price"><?= e(rupiah((int)$it['price'])) ?></span>
                        </div>
                        <?php if ($it['description'] !== ''): ?><p><?= e($it['description']) ?></p><?php endif; ?>
                        <span class="dish-cat"><?= e($it['category']) ?></span>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p class="menu-empty">Menu sedang disiapkan. Silakan kembali lagi nanti.</p>
    <?php endif;
    if ($admin): ?>
        <div class="menu-add">
            <button type="button" class="btn btn-gold" data-menu-add><?= icon('plus', 18) ?> Tambah Menu</button>
        </div>
    <?php endif;
    return (string)ob_get_clean();
}
