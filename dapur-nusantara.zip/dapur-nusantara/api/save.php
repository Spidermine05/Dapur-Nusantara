<?php
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';

// Menyimpan perubahan teks dari mode edit. Body: {"changes": {"kunci": "nilai", ...}}
try {
    api_guard();

    $input   = json_decode((string)file_get_contents('php://input'), true);
    $changes = is_array($input['changes'] ?? null) ? $input['changes'] : [];
    if (!$changes) {
        json_out(['ok' => false, 'error' => 'Tidak ada perubahan untuk disimpan.'], 422);
    }

    $allowed = defaults();
    $pdo = db();
    $pdo->beginTransaction();
    $saved = 0;
    foreach ($changes as $key => $value) {
        // Hanya kunci yang dikenal yang boleh disimpan
        if (!is_string($key) || !array_key_exists($key, $allowed) || !is_string($value)) {
            continue;
        }
        set_setting($key, clean_text($value, 1500));
        $saved++;
    }
    $pdo->commit();

    json_out(['ok' => true, 'saved' => $saved]);
} catch (Throwable $ex) {
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_out(['ok' => false, 'error' => 'Gagal menyimpan: ' . $ex->getMessage()], 500);
}
