<?php
declare(strict_types=1);
require __DIR__ . '/../includes/bootstrap.php';
require __DIR__ . '/../includes/render.php';

// Tambah / ubah / hapus menu. Form-data: action=save|delete, id, name, category, price, description, photo
try {
    api_guard();
    $pdo    = db();
    $action = (string)($_POST['action'] ?? '');
    $id     = (int)($_POST['id'] ?? 0);

    if ($action === 'delete') {
        $st = $pdo->prepare('SELECT image FROM menu WHERE id = ?');
        $st->execute([$id]);
        $row = $st->fetch();
        if (!$row) {
            json_out(['ok' => false, 'error' => 'Menu tidak ditemukan.'], 404);
        }
        $pdo->prepare('DELETE FROM menu WHERE id = ?')->execute([$id]);
        delete_upload($row['image']);
        json_out(['ok' => true, 'html' => render_menu(true)]);
    }

    if ($action !== 'save') {
        json_out(['ok' => false, 'error' => 'Aksi tidak dikenal.'], 422);
    }

    $name     = clean_text((string)($_POST['name'] ?? ''), 80);
    $category = clean_text((string)($_POST['category'] ?? ''), 40);
    $desc     = clean_text((string)($_POST['description'] ?? ''), 400);
    $price    = max(0, min(100000000, (int)preg_replace('/\D+/', '', (string)($_POST['price'] ?? '0'))));

    if ($name === '' || $category === '') {
        json_out(['ok' => false, 'error' => 'Nama dan kategori menu wajib diisi.'], 422);
    }
    $category = preg_replace('/\s+/', ' ', str_replace("\n", ' ', $category)) ?? $category;
    $name     = preg_replace('/\s+/', ' ', str_replace("\n", ' ', $name)) ?? $name;

    $hasPhoto = isset($_FILES['photo']) && ($_FILES['photo']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
    $newImage = $hasPhoto ? save_upload($_FILES['photo']) : null;

    if ($id > 0) {
        $st = $pdo->prepare('SELECT image FROM menu WHERE id = ?');
        $st->execute([$id]);
        $row = $st->fetch();
        if (!$row) {
            json_out(['ok' => false, 'error' => 'Menu tidak ditemukan.'], 404);
        }
        $image = $newImage ?? $row['image'];
        if (!empty($_POST['remove_photo']) && $newImage === null) {
            $image = null;
        }
        $pdo->prepare('UPDATE menu SET category = ?, name = ?, description = ?, price = ?, image = ? WHERE id = ?')
            ->execute([$category, $name, $desc, $price, $image, $id]);
        if ($image !== $row['image']) {
            delete_upload($row['image']);
        }
    } else {
        $pdo->prepare('INSERT INTO menu (category, name, description, price, image) VALUES (?, ?, ?, ?, ?)')
            ->execute([$category, $name, $desc, $price, $newImage]);
    }

    json_out(['ok' => true, 'html' => render_menu(true)]);
} catch (RuntimeException $ex) {
    json_out(['ok' => false, 'error' => $ex->getMessage()], 422);
} catch (Throwable $ex) {
    json_out(['ok' => false, 'error' => 'Terjadi kesalahan: ' . $ex->getMessage()], 500);
}
