<?php
declare(strict_types=1);
require __DIR__ . '/includes/bootstrap.php';
require __DIR__ . '/includes/render.php';

if (is_admin()) {
    redirect('index.php');
}

$setup = !has_users();   // Pertama kali dijalankan: buat akun admin
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid($_POST['csrf'] ?? null)) {
        $error = 'Sesi kedaluwarsa. Silakan coba lagi.';
    } elseif ($setup) {
        $user = trim((string)($_POST['username'] ?? ''));
        $pass = (string)($_POST['password'] ?? '');
        $conf = (string)($_POST['confirm'] ?? '');
        if (!preg_match('/^[A-Za-z0-9_.-]{3,30}$/', $user)) {
            $error = 'Username 3–30 karakter (huruf, angka, titik, strip, atau garis bawah).';
        } elseif (strlen($pass) < 8) {
            $error = 'Kata sandi minimal 8 karakter.';
        } elseif ($pass !== $conf) {
            $error = 'Konfirmasi kata sandi tidak sama.';
        } else {
            db()->prepare('INSERT INTO users (username, password_hash) VALUES (?, ?)')
                ->execute([$user, password_hash($pass, PASSWORD_DEFAULT)]);
            session_regenerate_id(true);
            $_SESSION['uid'] = (int)db()->lastInsertId();
            redirect('index.php');
        }
    } else {
        $locked = (int)($_SESSION['lock_until'] ?? 0);
        if ($locked > time()) {
            $error = 'Terlalu banyak percobaan. Coba lagi dalam ' . ($locked - time()) . ' detik.';
        } else {
            $st = db()->prepare('SELECT id, password_hash FROM users WHERE username = ?');
            $st->execute([trim((string)($_POST['username'] ?? ''))]);
            $row = $st->fetch();
            if ($row && password_verify((string)($_POST['password'] ?? ''), $row['password_hash'])) {
                session_regenerate_id(true);
                $_SESSION['uid'] = (int)$row['id'];
                unset($_SESSION['fails'], $_SESSION['lock_until']);
                redirect('index.php');
            }
            usleep(400000);
            $_SESSION['fails'] = (int)($_SESSION['fails'] ?? 0) + 1;
            if ($_SESSION['fails'] >= 5) {
                $_SESSION['lock_until'] = time() + 60;
                $_SESSION['fails'] = 0;
            }
            $error = 'Username atau kata sandi salah.';
        }
    }
}
?><!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?= $setup ? 'Buat Akun Admin' : 'Masuk' ?> · <?= et('brand.name') ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="page-auth">
    <main class="auth-card">
        <a href="index.php" class="auth-brand"><?= icon('flame', 26) ?> <span><?= et('brand.name') ?></span></a>
        <h1><?= $setup ? 'Buat Akun Admin' : 'Masuk untuk Mengedit' ?></h1>
        <p class="auth-sub">
            <?= $setup
                ? 'Selamat datang! Buat akun admin pertama Anda. Akun ini dipakai untuk mengedit website langsung dari halaman utama.'
                : 'Setelah masuk, Anda bisa mengubah teks, foto, dan menu langsung di halaman website.' ?>
        </p>

        <?php if ($error): ?><div class="alert alert-err" role="alert"><?= e($error) ?></div><?php endif; ?>

        <form method="post" autocomplete="on" class="form">
            <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
            <label>Username
                <input type="text" name="username" required autofocus autocomplete="username"
                       value="<?= e((string)($_POST['username'] ?? '')) ?>">
            </label>
            <label>Kata sandi
                <input type="password" name="password" required minlength="<?= $setup ? 8 : 1 ?>"
                       autocomplete="<?= $setup ? 'new-password' : 'current-password' ?>">
            </label>
            <?php if ($setup): ?>
                <label>Ulangi kata sandi
                    <input type="password" name="confirm" required minlength="8" autocomplete="new-password">
                </label>
            <?php endif; ?>
            <button type="submit" class="btn btn-gold btn-block"><?= $setup ? 'Buat Akun & Masuk' : 'Masuk' ?></button>
        </form>
        <a class="auth-back" href="index.php">← Kembali ke website</a>
    </main>
</body>
</html>
